document.addEventListener('DOMContentLoaded', async () => {
  try {
    const response = await fetch('/api/usuarios');
    const usuarios = await response.json();
    const usuariosLista = document.getElementById('usuarios-lista');

    usuarios.forEach(usuario => {
      const li = document.createElement('li');
      li.textContent = `${usuario.nombre} - ${usuario.email} - ${usuario.tipo}`;

      const eliminarBtn = document.createElement('button');
      eliminarBtn.textContent = 'Eliminar';
      eliminarBtn.addEventListener('click', async () => {
        try {
          await fetch(`/api/usuarios/${usuario.id}`, {
            method: 'DELETE'
          });
          li.remove();
        } catch (error) {
          console.error('Error al eliminar usuario:', error);
        }
      });

      li.appendChild(eliminarBtn);
      usuariosLista.appendChild(li);
    });
  } catch (error) {
    console.error('Error al obtener usuarios:', error);
  }
});

  