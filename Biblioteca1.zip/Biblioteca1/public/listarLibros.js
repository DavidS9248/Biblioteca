document.addEventListener('DOMContentLoaded', async () => {
  try {
    const response = await fetch('/api/libros');
    const libros = await response.json();
    const librosLista = document.getElementById('libros-lista');

    libros.forEach(libro => {
      const li = document.createElement('li');
      li.textContent = `${libro.titulo} - ${libro.autor}`;

      const eliminarBtn = document.createElement('button');
      eliminarBtn.textContent = 'Eliminar';
      eliminarBtn.addEventListener('click', async () => {
        try {
          await fetch(`/api/libros/${libro.id}`, {
            method: 'DELETE'
          });
          li.remove();
        } catch (error) {
          console.error('Error al eliminar libro:', error);
        }
      });

      li.appendChild(eliminarBtn);
      librosLista.appendChild(li);
    });
  } catch (error) {
    console.error('Error al obtener libros:', error);
  }
});

  