const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));


app.get('/api/usuarios', (req, res) => {
  fs.readFile(path.join(__dirname, 'datos', 'usuarios.json'), 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ message: 'Error al leer usuarios' });
    }
    res.json(JSON.parse(data));
  });
});


app.post('/api/usuarios', (req, res) => {
  fs.readFile(path.join(__dirname, 'datos', 'usuarios.json'), 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ message: 'Error al leer usuarios' });
    }
    const usuarios = JSON.parse(data);
    const nuevoUsuario = { id: Date.now(), ...req.body };
    usuarios.push(nuevoUsuario);

    fs.writeFile(path.join(__dirname, 'datos', 'usuarios.json'), JSON.stringify(usuarios, null, 2), (err) => {
      if (err) {
        return res.status(500).json({ message: 'Error al guardar usuario' });
      }
      res.json({ message: 'Usuario registrado con éxito' });
    });
  });
});


app.delete('/api/usuarios/:id', (req, res) => {
  fs.readFile(path.join(__dirname, 'datos', 'usuarios.json'), 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ message: 'Error al leer usuarios' });
    }
    const usuarios = JSON.parse(data);
    const usuariosActualizados = usuarios.filter(usuario => usuario.id !== parseInt(req.params.id));

    fs.writeFile(path.join(__dirname, 'datos', 'usuarios.json'), JSON.stringify(usuariosActualizados, null, 2), (err) => {
      if (err) {
        return res.status(500).json({ message: 'Error al guardar usuarios' });
      }
      res.json({ message: 'Usuario eliminado con éxito' });
    });
  });
});


app.get('/api/libros', (req, res) => {
  fs.readFile(path.join(__dirname, 'datos', 'libros.json'), 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ message: 'Error al leer libros' });
    }
    res.json(JSON.parse(data));
  });
});


app.post('/api/libros', (req, res) => {
  fs.readFile(path.join(__dirname, 'datos', 'libros.json'), 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ message: 'Error al leer libros' });
    }
    const libros = JSON.parse(data);
    const nuevoLibro = { id: Date.now(), ...req.body };
    libros.push(nuevoLibro);

    fs.writeFile(path.join(__dirname, 'datos', 'libros.json'), JSON.stringify(libros, null, 2), (err) => {
      if (err) {
        return res.status(500).json({ message: 'Error al guardar libro' });
      }
      res.json({ message: 'Libro registrado con éxito' });
    });
  });
});


app.delete('/api/libros/:id', (req, res) => {
  fs.readFile(path.join(__dirname, 'datos', 'libros.json'), 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ message: 'Error al leer libros' });
    }
    const libros = JSON.parse(data);
    const librosActualizados = libros.filter(libro => libro.id !== parseInt(req.params.id));

    fs.writeFile(path.join(__dirname, 'datos', 'libros.json'), JSON.stringify(librosActualizados, null, 2), (err) => {
      if (err) {
        return res.status(500).json({ message: 'Error al guardar libros' });
      }
      res.json({ message: 'Libro eliminado con éxito' });
    });
  });
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
  
module.exports = app;

});
  