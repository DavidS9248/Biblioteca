const { getByLabelText, getByText, fireEvent } = require('@testing-library/dom');

document.body.innerHTML = `
  <form id="registro-form">
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" required>

    <label for="email">Email:</label>
    <input type="email" id="email" required>

    <label for="tipo">Tipo:</label>
    <select id="tipo" required>
      <option value="adulto">Adulto</option>
      <option value="niño">Niño</option>
    </select>

    <button type="submit">Registrar</button>
  </form>
`;

require('../public/registroUsuario.js');

describe('Formulario de Registro de Usuario', () => {
  it('Debería registrar un usuario al enviar el formulario', async () => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () => Promise.resolve({ message: 'Usuario registrado con éxito' }),
      })
    );

    const nombreInput = getByLabelText(document.body, 'Nombre:');
    const emailInput = getByLabelText(document.body, 'Email:');
    const tipoSelect = getByLabelText(document.body, 'Tipo:');
    const submitButton = getByText(document.body, 'Registrar');

    fireEvent.input(nombreInput, { target: { value: 'Pedro' } });
    fireEvent.input(emailInput, { target: { value: 'pedro@example.com' } });
    fireEvent.change(tipoSelect, { target: { value: 'niño' } });
    fireEvent.click(submitButton);

    expect(global.fetch).toHaveBeenCalledWith('/api/usuarios', expect.objectContaining({
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre: 'Pedro', email: 'pedro@example.com', tipo: 'niño' }),
    }));

    // Puedes agregar más expectativas aquí para verificar el comportamiento después de la llamada fetch
  });
});
