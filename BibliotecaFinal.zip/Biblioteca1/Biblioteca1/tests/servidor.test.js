const request = require('supertest');
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = require('../servidor');

jest.mock('fs');

describe('API Usuarios', () => {
  it('Debería obtener todos los usuarios', async () => {
    const mockData = JSON.stringify([{ id: 1, nombre: 'Juan', email: 'juan@example.com', tipo: 'adulto' }]);
    fs.readFile.mockImplementation((path, encoding, callback) => {
      callback(null, mockData);
    });

    const response = await request(app).get('/api/usuarios');
    expect(response.status).toBe(200);
    expect(response.body).toEqual([{ id: 1, nombre: 'Juan', email: 'juan@example.com', tipo: 'adulto' }]);
  });

  it('Debería registrar un nuevo usuario', async () => {
    const mockData = JSON.stringify([]);
    fs.readFile.mockImplementation((path, encoding, callback) => {
      callback(null, mockData);
    });
    fs.writeFile.mockImplementation((path, data, callback) => {
      callback(null);
    });

    const newUser = { nombre: 'Pedro', email: 'pedro@example.com', tipo: 'niño' };
    const response = await request(app).post('/api/usuarios').send(newUser);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Usuario registrado con éxito');
  });
});

describe('API Libros', () => {
  it('Debería obtener todos los libros', async () => {
    const mockData = JSON.stringify([{ id: 1, titulo: 'Libro 1', autor: 'Autor 1' }]);
    fs.readFile.mockImplementation((path, encoding, callback) => {
      callback(null, mockData);
    });

    const response = await request(app).get('/api/libros');
    expect(response.status).toBe(200);
    expect(response.body).toEqual([{ id: 1, titulo: 'Libro 1', autor: 'Autor 1' }]);
  });

  it('Debería registrar un nuevo libro', async () => {
    const mockData = JSON.stringify([]);
    fs.readFile.mockImplementation((path, encoding, callback) => {
      callback(null, mockData);
    });
    fs.writeFile.mockImplementation((path, data, callback) => {
      callback(null);
    });

    const newBook = { titulo: 'Nuevo Libro', autor: 'Nuevo Autor' };
    const response = await request(app).post('/api/libros').send(newBook);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Libro registrado con éxito');
  });
});
