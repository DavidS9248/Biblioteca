document.getElementById('registro-libro-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const titulo = document.getElementById('titulo').value;
  const autor = document.getElementById('autor').value;
  const passwordBook = document.getElementById('passwordBook').value;

  const adminPassword = 'admin123'; 

  if (passwordBook === adminPassword) {
    try {
      const response = await fetch('/api/libros', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ titulo, autor })
      });
      const result = await response.json();
      alert(result.message);
    } catch (error) {
      console.error('Error al registrar libro:', error);
    }
  } else {
    alert('Contraseña incorrecta.');
  }
});
