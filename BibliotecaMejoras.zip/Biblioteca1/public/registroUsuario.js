document.getElementById('registro-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const nombre = document.getElementById('nombre').value;
  const email = document.getElementById('email').value;
  const tipo = document.getElementById('tipo').value;
  const password = document.getElementById('password').value;

  
  const adminPassword = 'admin123';

  if (password === adminPassword) {
    try {
      const response = await fetch('/api/usuarios', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nombre, email, tipo })
      });
      const result = await response.json();
      alert(result.message);
    } catch (error) {
      console.error('Error al registrar usuario:', error);
    }
  } else {
    alert('Contraseña incorrecta.');
  }
});
